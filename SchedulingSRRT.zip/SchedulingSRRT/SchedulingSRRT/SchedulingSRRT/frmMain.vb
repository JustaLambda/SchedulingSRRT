﻿Imports System.IO
Imports System.Text.Json

Public Class frmMain
    Dim nTeamsStr As String
    Dim numberOfTeams As Integer
    Dim flagError As Integer       ' = 1 if there is some error, = 0 otherwise

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tbxNumberOfTeams.Text = ""
        rbtZeroWaitingTimeAllowed.Checked = False
        rbtZeroWaitingTimeNOTallowed.Checked = False
    End Sub

    Private Sub cmdMakeOptimalSchedule_Click(sender As Object, e As EventArgs) Handles cmdMakeOptimalSchedule.Click
        ' This is to schedule single round robin tournaments for odd number of teams
        ' optimizing simultaneously two objective functions:
        ' (i) total waiting times of all teams, and
        ' (ii) number of long waiting times.
        ' The algorithms for making the schedules are refered to the paper
        ' Sigrid Knust. Scheduling sports tournaments on a single court minimizing waiting times.
        ' Operational Research Letters, 36:471-476, 2008.

        ' Set cursor for the mouse pointer in waiting time during the procedure
        Me.Cursor = Cursors.WaitCursor()

        ' 1. Check the input information and option from interface
        flagError = 0

        ' 1i. Check whether the number of teams is given
        nTeamsStr = tbxNumberOfTeams.Text.Trim
        If nTeamsStr = "" Then
            flagError = 1
            MessageBox.Show("Please enter the number of teams!", "Message")
        End If

        ' 1ii. Check whether the number of teams is valid
        If flagError = 0 Then
            If Not Integer.TryParse(nTeamsStr, numberOfTeams) Then
                flagError = 1
                MessageBox.Show("The number of teams must be integral!", "Message")
            End If
        End If
        If flagError = 0 Then
            If numberOfTeams < 1 Or numberOfTeams Mod 2 = 0 Then
                flagError = 1
                MessageBox.Show("The number of teams must be a positive odd integer!", "Message")
            End If
        End If

        ' 1iii. Check whether the option about zero waiting times is chosen
        If flagError = 0 Then
            If rbtZeroWaitingTimeAllowed.Checked = False And rbtZeroWaitingTimeNOTallowed.Checked = False Then
                flagError = 1
                MessageBox.Show("Please choose an option about zero waiting time!", "Message")
            End If
        End If

        ' 2. Make schedule in case zero waiting times NOT allowed
        If flagError = 0 And rbtZeroWaitingTimeNOTallowed.Checked = True Then

            ' 2i. Create the 2-factor of slots in the second representation           
            Dim slot(0 To numberOfTeams - 1) As Integer      ' Array of slots in 2-factor in 2nd model
            Dim iSlot As Integer                             ' Index of slot in array
            Dim vSlot As Integer                             ' Original index value of each slot 

            ' Case of 3 teams is infeasible
            If numberOfTeams = 3 Then
                MessageBox.Show("Infeasible!", "Message")
                ' Set default cursor for the mouse pointer after doing the procedure
                Me.Cursor = Cursors.Default()
                Exit Sub
            End If

            ' Case of 5 teams
            If numberOfTeams = 5 Then
                slot(0) = 1
                slot(1) = 3
                slot(2) = 5
                slot(3) = 2
                slot(4) = 4
            End If

            ' Case of 7 teams
            If numberOfTeams = 7 Then
                slot(0) = 1
                slot(1) = 3
                slot(2) = 6
                slot(3) = 2
                slot(4) = 5
                slot(5) = 7
                slot(6) = 4
            End If

            ' Case of 9 teams
            If numberOfTeams = 9 Then
                slot(0) = 1
                slot(1) = 3
                slot(2) = 7
                slot(3) = 9
                slot(4) = 6
                slot(5) = 8
                slot(6) = 5
                slot(7) = 2
                slot(8) = 4
            End If

            ' Case of 11 teams or more
            If numberOfTeams >= 11 Then
                slot(0) = 1
                slot(1) = 3
                iSlot = 2
                For vSlot = 6 To numberOfTeams - 5 Step 2
                    slot(iSlot) = vSlot
                    iSlot = iSlot + 1
                Next
                slot(iSlot) = numberOfTeams - 2
                iSlot = iSlot + 1
                slot(iSlot) = numberOfTeams
                iSlot = iSlot + 1
                slot(iSlot) = numberOfTeams - 3
                iSlot = iSlot + 1
                slot(iSlot) = numberOfTeams - 1
                iSlot = iSlot + 1
                For vSlot = numberOfTeams - 4 To 5 Step -2
                    slot(iSlot) = vSlot
                    iSlot = iSlot + 1
                Next
                slot(iSlot) = 2
                iSlot = iSlot + 1
                slot(iSlot) = 4
            End If

            ' 2ii. 2-factors of complete graph in 1st model
            Dim numberOfRounds As Integer = (numberOfTeams - 1) / 2
            Dim KnFactors(0 To numberOfRounds - 1, 0 To numberOfTeams - 1) As Integer
            Dim iRound As Integer
            Dim iTeam As Integer

            ' Case of 3 teams is infeasible and already announced

            ' Case of 5 teams
            If numberOfTeams = 5 Then
                ' 1st factor
                KnFactors(0, 0) = 1
                KnFactors(0, 1) = 2
                KnFactors(0, 2) = 3
                KnFactors(0, 3) = 4
                KnFactors(0, 4) = 5
                ' 2nd factor
                KnFactors(1, 0) = 1
                KnFactors(1, 1) = 3
                KnFactors(1, 2) = 5
                KnFactors(1, 3) = 2
                KnFactors(1, 4) = 4
            End If

            ' Case of 7 teams
            If numberOfTeams = 7 Then
                ' 1st factor
                KnFactors(0, 0) = 1
                KnFactors(0, 1) = 2
                KnFactors(0, 2) = 3
                KnFactors(0, 3) = 4
                KnFactors(0, 4) = 5
                KnFactors(0, 5) = 6
                KnFactors(0, 6) = 7
                ' 2nd factor
                KnFactors(1, 0) = 1
                KnFactors(1, 1) = 3
                KnFactors(1, 2) = 5
                KnFactors(1, 3) = 7
                KnFactors(1, 4) = 2
                KnFactors(1, 5) = 4
                KnFactors(1, 6) = 6
                ' 3rd factor
                KnFactors(2, 0) = 1
                KnFactors(2, 1) = 4
                KnFactors(2, 2) = 7
                KnFactors(2, 3) = 3
                KnFactors(2, 4) = 6
                KnFactors(2, 5) = 2
                KnFactors(2, 6) = 5
            End If

            ' Case of 9 teams
            If numberOfTeams = 9 Then
                ' 1st factor
                KnFactors(0, 0) = 1
                KnFactors(0, 1) = 2
                KnFactors(0, 2) = 8
                KnFactors(0, 3) = 3
                KnFactors(0, 4) = 7
                KnFactors(0, 5) = 4
                KnFactors(0, 6) = 6
                KnFactors(0, 7) = 5
                KnFactors(0, 8) = 9
                ' 2nd factor
                KnFactors(1, 0) = 1
                KnFactors(1, 1) = 4
                KnFactors(1, 2) = 8
                KnFactors(1, 3) = 5
                KnFactors(1, 4) = 7
                KnFactors(1, 5) = 6
                KnFactors(1, 6) = 9
                KnFactors(1, 7) = 2
                KnFactors(1, 8) = 3
                ' 3rd factor
                KnFactors(2, 0) = 1
                KnFactors(2, 1) = 6
                KnFactors(2, 2) = 8
                KnFactors(2, 3) = 7
                KnFactors(2, 4) = 9
                KnFactors(2, 5) = 3
                KnFactors(2, 6) = 4
                KnFactors(2, 7) = 2
                KnFactors(2, 8) = 5
                ' 4th factor
                KnFactors(3, 0) = 1
                KnFactors(3, 1) = 8
                KnFactors(3, 2) = 9
                KnFactors(3, 3) = 4
                KnFactors(3, 4) = 5
                KnFactors(3, 5) = 3
                KnFactors(3, 6) = 6
                KnFactors(3, 7) = 2
                KnFactors(3, 8) = 7
            End If

            ' Case of 11 teams or more          
            If numberOfTeams >= 11 Then
                For iRound = 0 To numberOfRounds - 1
                    KnFactors(iRound, 0) = numberOfTeams
                    KnFactors(iRound, 1) = (iRound + 1) Mod (numberOfTeams - 1)
                    For iTeam = 2 To numberOfTeams - 1
                        If iTeam Mod 2 = 0 Then
                            KnFactors(iRound, iTeam) = (iRound + 1 + iTeam / 2) Mod (numberOfTeams - 1)
                        Else
                            KnFactors(iRound, iTeam) = (numberOfTeams + iRound + 1 - (iTeam + 1) / 2) Mod (numberOfTeams - 1)
                        End If
                        If KnFactors(iRound, iTeam) = 0 Then
                            KnFactors(iRound, iTeam) = numberOfTeams - 1
                        End If
                    Next
                Next
            End If

            ' 2iii. Make schedule
            Dim scheduleLeft(0 To numberOfRounds - 1, 0 To numberOfTeams - 1) As Integer
            Dim scheduleRight(0 To numberOfRounds - 1, 0 To numberOfTeams - 1) As Integer

            For iRound = 0 To numberOfRounds - 1
                scheduleLeft(iRound, slot(0) - 1) = KnFactors(iRound, numberOfTeams - 1)
                scheduleRight(iRound, slot(0) - 1) = KnFactors(iRound, 0)
                For iSlot = 1 To numberOfTeams - 1
                    scheduleLeft(iRound, slot(iSlot) - 1) = KnFactors(iRound, iSlot - 1)
                    scheduleRight(iRound, slot(iSlot) - 1) = KnFactors(iRound, iSlot)
                Next
            Next

            ' 2iv. Save schedule into file (on desktop)
            Dim basePath As String            ' Directory containing the schedule file (to be on desktop)
            Dim fileName As String            ' Name of file result containing the optimal schedule
            Dim fileToWrite As String         ' File result with full directory
            Dim writeFile As System.IO.TextWriter
            Dim stringLine As String

            basePath = My.Computer.FileSystem.SpecialDirectories.Desktop + "\"
            fileName = "NoZeroWT" + numberOfTeams.ToString() + ".txt"
            fileToWrite = basePath + fileName

            If System.IO.File.Exists(fileToWrite) = True Then
                System.IO.File.Delete(fileToWrite)
            End If

            Try
                writeFile = New StreamWriter(fileToWrite)
                ' Decoration
                writeFile.WriteLine("Optimal schedule with no zero waiting times for " + numberOfTeams.ToString() + " teams")
                stringLine = "          "
                For iSlot = 1 To numberOfTeams
                    stringLine = stringLine + "  Match " + iSlot.ToString.PadRight(5)
                Next
                writeFile.WriteLine(stringLine)
                ' Print schedule
                For iRound = 0 To numberOfRounds - 1
                    stringLine = "Round " + (iRound + 1).ToString.PadRight(3)
                    For iSlot = 0 To numberOfTeams - 1
                        stringLine = stringLine + scheduleLeft(iRound, iSlot).ToString.PadLeft(5)
                        stringLine = stringLine + " - "
                        stringLine = stringLine + scheduleRight(iRound, iSlot).ToString.PadRight(5)
                    Next
                    writeFile.WriteLine(stringLine)
                Next

                writeFile.Flush()
                writeFile.Close()
                writeFile = Nothing
            Catch ex As IOException
                MsgBox(ex.ToString)
            End Try

            MessageBox.Show("Optimal schedule saved in " + fileToWrite, "Information")
        End If

        ' 3. Make schedule in case zero waiting times allowed (ONLY AVAILABLE FOR AT MOST 19 TEAMS)
        If flagError = 0 And rbtZeroWaitingTimeAllowed.Checked = True Then

            If numberOfTeams >= 21 Then
                MessageBox.Show("Currently, we are only able to print out schedule for at most 19 teams!", "Information")
                ' Set default cursor for the mouse pointer after doing the procedure
                Me.Cursor = Cursors.Default()
                Exit Sub
            End If

            ' 3i. Slot order in the second representation 
            Dim slot(0 To numberOfTeams - 1) As Integer
            Dim iSlot As Integer

            ' If numberOfTeams Mod 6 = 3, then every three consecutive slots (counted from beginning) form a cycle
            If numberOfTeams = 3 Or numberOfTeams = 9 Or numberOfTeams = 15 Then
                For iSlot = 0 To numberOfTeams - 1
                    slot(iSlot) = iSlot + 1
                Next
            End If

            ' Case of 5 teams as a particular case
            If numberOfTeams = 5 Then
                slot(0) = 1
                slot(1) = 2
                slot(2) = 4
                slot(3) = 5
                slot(4) = 3
            End If

            ' Case of 11 teams as a particular case
            If numberOfTeams = 11 Then
                slot(0) = 1
                slot(1) = 2
                slot(2) = 4
                slot(3) = 3
                slot(4) = 5
                slot(5) = 6
                slot(6) = 8
                slot(7) = 7
                For iSlot = 8 To numberOfTeams - 1
                    slot(iSlot) = iSlot + 1
                Next
            End If

            ' If numberOfTeams Mod 6 = 5 and numberOfTeams <> 11, then there is a cycle of length 5 and others of length 3
            If numberOfTeams = 17 Then
                slot(0) = 1
                slot(1) = 2
                slot(2) = 4
                slot(3) = 5
                slot(4) = 3
                For iSlot = 5 To numberOfTeams - 1
                    slot(iSlot) = iSlot + 1
                Next
            End If

            ' If numberOfTeams Mod 6 = 1, then there is a cycle of length 4 and others of length 3
            If numberOfTeams = 7 Or numberOfTeams = 13 Or numberOfTeams = 19 Then
                slot(0) = 1
                slot(1) = 2
                slot(2) = 4
                slot(3) = 3
                For iSlot = 4 To numberOfTeams - 1
                    slot(iSlot) = iSlot + 1
                Next
            End If

            ' 3ii. Number of cycles in the first 2-factor of complete graph in 1st model
            Dim numberOfCycles As Integer

            ' Case of numberOfTeams Mod 6 = 3:
            ' numberOfCycles = numberOfTeams / 3
            If numberOfTeams = 3 Or numberOfTeams = 9 Or numberOfTeams = 15 Then
                numberOfCycles = numberOfTeams / 3
            End If

            ' Case of numberOfTeams Mod 6 = 5 (except for numberOfTeams = 11):
            ' one cycle of length 5 and others of length 3
            If numberOfTeams = 5 Then
                numberOfCycles = 1
            End If
            If numberOfTeams = 17 Then
                numberOfCycles = 5
            End If

            ' Case of numberOfTeams = 11 as a particular case:
            ' two cycles of length 4 and one cycle of length 3
            If numberOfTeams = 11 Then
                numberOfCycles = 3
            End If

            ' Case of numberOfTeams Mod 6 = 1:
            ' one cycle of length 4 and others of length 3
            If numberOfTeams = 7 Or numberOfTeams = 13 Or numberOfTeams = 19 Then
                numberOfCycles = (numberOfTeams - 1) / 3
            End If

            ' 3iii. Length of each cycle in the first 2-factor of complete graph in 1st model
            Dim lengthOfCycles(0 To numberOfCycles - 1) As Integer
            Dim iCycle As Integer

            ' Case of numberOfTeams Mod 6 = 3:
            ' every cycle is of length 3
            If numberOfTeams = 3 Or numberOfTeams = 9 Or numberOfTeams = 15 Then
                For iCycle = 0 To numberOfCycles - 1
                    lengthOfCycles(iCycle) = 3
                Next
            End If

            ' Case of numberOfTeams Mod 6 = 5 (except for numberOfTeams = 11):
            ' one cycle of length 5 and others of length 3
            If numberOfTeams = 5 Then
                lengthOfCycles(0) = 5
            End If
            If numberOfTeams = 17 Then
                lengthOfCycles(0) = 5
                For iCycle = 1 To numberOfCycles - 1
                    lengthOfCycles(iCycle) = 3
                Next
            End If

            ' Case of numberOfTeams = 11 as a particular case:
            ' two cycles of length 4 and one cycle of length 3
            If numberOfTeams = 11 Then
                lengthOfCycles(0) = 4
                lengthOfCycles(1) = 4
                lengthOfCycles(2) = 3
            End If

            ' Case of numberOfTeams Mod 6 = 1:
            ' one cycle of length 4 and others of length 3
            If numberOfTeams = 7 Or numberOfTeams = 13 Or numberOfTeams = 19 Then
                lengthOfCycles(0) = 4
                For iCycle = 1 To numberOfCycles - 1
                    lengthOfCycles(0) = 3
                Next
            End If

            ' 3iv. Cycles in the first 2-factor of complete graph in 1st model
            Dim cycles(0 To numberOfCycles - 1, 0 To lengthOfCycles(0) - 1) As Integer

            ' Case of 3 teams
            If numberOfTeams = 3 Then
                cycles(0, 0) = 1
                cycles(0, 1) = 2
                cycles(0, 2) = 3
            End If

            ' Case of 5 teams
            If numberOfTeams = 5 Then
                cycles(0, 0) = 1
                cycles(0, 1) = 2
                cycles(0, 2) = 4
                cycles(0, 3) = 3
                cycles(0, 4) = 5
            End If

            ' Case of 7 teams
            If numberOfTeams = 7 Then
                cycles(0, 0) = 2
                cycles(0, 1) = 3
                cycles(0, 2) = 5
                cycles(0, 3) = 6
                cycles(1, 0) = 1
                cycles(1, 1) = 4
                cycles(1, 2) = 7
            End If

            ' Case of 9 teams
            If numberOfTeams = 9 Then
                cycles(0, 0) = 1
                cycles(0, 1) = 5
                cycles(0, 2) = 9
                cycles(1, 0) = 2
                cycles(1, 1) = 3
                cycles(1, 2) = 8
                cycles(2, 0) = 4
                cycles(2, 1) = 6
                cycles(2, 2) = 7
            End If

            ' Case of 11 teams
            If numberOfTeams = 11 Then
                cycles(0, 0) = 2
                cycles(0, 1) = 3
                cycles(0, 2) = 5
                cycles(0, 3) = 9
                cycles(1, 0) = 4
                cycles(1, 1) = 7
                cycles(1, 2) = 8
                cycles(1, 3) = 10
                cycles(2, 0) = 1
                cycles(2, 1) = 6
                cycles(2, 2) = 11
            End If

            ' Case of 13 teams
            If numberOfTeams = 13 Then
                cycles(0, 0) = 3
                cycles(0, 1) = 5
                cycles(0, 2) = 4
                cycles(0, 3) = 8
                cycles(1, 0) = 1
                cycles(1, 1) = 7
                cycles(1, 2) = 13
                cycles(2, 0) = 2
                cycles(2, 1) = 6
                cycles(2, 2) = 11
                cycles(3, 0) = 9
                cycles(3, 1) = 10
                cycles(3, 2) = 12
            End If

            ' Case of 15 teams
            If numberOfTeams = 15 Then
                cycles(0, 0) = 1
                cycles(0, 1) = 8
                cycles(0, 2) = 15
                cycles(1, 0) = 2
                cycles(1, 1) = 6
                cycles(1, 2) = 12
                cycles(2, 0) = 3
                cycles(2, 1) = 5
                cycles(2, 2) = 14
                cycles(3, 0) = 4
                cycles(3, 1) = 7
                cycles(3, 2) = 13
                cycles(4, 0) = 9
                cycles(4, 1) = 10
                cycles(4, 2) = 11
            End If

            ' Case of 17 teams
            If numberOfTeams = 17 Then
                cycles(0, 0) = 2
                cycles(0, 1) = 7
                cycles(0, 2) = 3
                cycles(0, 3) = 10
                cycles(0, 4) = 8
                cycles(1, 0) = 1
                cycles(1, 1) = 9
                cycles(1, 2) = 17
                cycles(2, 0) = 4
                cycles(2, 1) = 5
                cycles(2, 2) = 16
                cycles(3, 0) = 6
                cycles(3, 1) = 12
                cycles(3, 2) = 15
                cycles(4, 0) = 11
                cycles(4, 1) = 13
                cycles(4, 2) = 14
            End If

            ' Case of 19 teams
            If numberOfTeams = 19 Then
                cycles(0, 0) = 6
                cycles(0, 1) = 8
                cycles(0, 2) = 7
                cycles(0, 3) = 11
                cycles(1, 0) = 1
                cycles(1, 1) = 10
                cycles(1, 2) = 19
                cycles(2, 0) = 2
                cycles(2, 1) = 5
                cycles(2, 2) = 13
                cycles(3, 0) = 3
                cycles(3, 1) = 9
                cycles(3, 2) = 16
                cycles(4, 0) = 4
                cycles(4, 1) = 12
                cycles(4, 2) = 18
                cycles(5, 0) = 14
                cycles(5, 1) = 15
                cycles(5, 2) = 17
            End If

            ' 3v. Make schedule
            Dim numberOfRounds As Integer = (numberOfTeams - 1) / 2
            Dim scheduleLeft(0 To numberOfRounds - 1, 0 To numberOfTeams - 1) As Integer
            Dim scheduleRight(0 To numberOfRounds - 1, 0 To numberOfTeams - 1) As Integer
            Dim iRound As Integer
            Dim i, j, i0, d As Integer

            j = 0
            For iRound = 0 To numberOfRounds - 1
                iSlot = 0
                For iCycle = 0 To numberOfCycles - 1
                    i = cycles(iCycle, 0)
                    If i > 0 And i <> numberOfTeams Then
                        i = (i + iRound) Mod (numberOfTeams - 1)
                        If i = 0 Then
                            i = numberOfTeams - 1
                        End If
                    End If
                    i0 = i
                    For d = 1 To lengthOfCycles(iCycle) - 1
                        j = cycles(iCycle, d)
                        If j > 0 And j <> numberOfTeams Then
                            j = (j + iRound) Mod (numberOfTeams - 1)
                            If j = 0 Then
                                j = numberOfTeams - 1
                            End If
                        End If
                        scheduleLeft(iRound, slot(iSlot) - 1) = i
                        scheduleRight(iRound, slot(iSlot) - 1) = j
                        i = j
                        iSlot = iSlot + 1
                    Next
                    scheduleLeft(iRound, slot(iSlot) - 1) = j
                    scheduleRight(iRound, slot(iSlot) - 1) = i0
                    iSlot = iSlot + 1
                Next
            Next

            ' 3vi. Save schedule into file (on desktop)
            Dim basePath As String            ' Directory containing the schedule file (to be on desktop)
            Dim fileName As String            ' Name of file result containing the optimal schedule
            Dim fileToWrite As String         ' File result with full directory
            Dim writeFile As System.IO.TextWriter
            Dim stringLine As String

            basePath = My.Computer.FileSystem.SpecialDirectories.Desktop + "\"
            fileName = "ZeroWT" + numberOfTeams.ToString() + ".txt"
            fileToWrite = basePath + fileName

            If System.IO.File.Exists(fileToWrite) = True Then
                System.IO.File.Delete(fileToWrite)
            End If

            Try
                writeFile = New StreamWriter(fileToWrite)
                ' Decoration
                writeFile.WriteLine("Optimal schedule with zero waiting times allowed for " + numberOfTeams.ToString() + " teams")
                stringLine = "          "
                For iSlot = 1 To numberOfTeams
                    stringLine = stringLine + "  Match " + iSlot.ToString.PadRight(5)
                Next
                writeFile.WriteLine(stringLine)
                ' Print schedule
                For iRound = 0 To numberOfRounds - 1
                    stringLine = "Round " + (iRound + 1).ToString.PadRight(3)
                    For iSlot = 0 To numberOfTeams - 1
                        stringLine = stringLine + scheduleLeft(iRound, iSlot).ToString.PadLeft(5)
                        stringLine = stringLine + " - "
                        stringLine = stringLine + scheduleRight(iRound, iSlot).ToString.PadRight(5)
                    Next
                    writeFile.WriteLine(stringLine)
                Next

                writeFile.Flush()
                writeFile.Close()
                writeFile = Nothing
            Catch ex As IOException
                MsgBox(ex.ToString)
            End Try

            MessageBox.Show("Optimal schedule saved in " + fileToWrite, "Information")
        End If

        ' Set default cursor for the mouse pointer after doing the procedure
        Me.Cursor = Cursors.Default()
    End Sub
End Class
