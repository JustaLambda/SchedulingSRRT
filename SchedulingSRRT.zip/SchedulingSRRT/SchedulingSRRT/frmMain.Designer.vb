﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        lblTitle = New Label()
        lblNumberOfTeams = New Label()
        tbxNumberOfTeams = New TextBox()
        rbtZeroWaitingTimeAllowed = New RadioButton()
        rbtZeroWaitingTimeNOTallowed = New RadioButton()
        cmdMakeOptimalSchedule = New Button()
        SuspendLayout()
        ' 
        ' lblTitle
        ' 
        lblTitle.AutoSize = True
        lblTitle.Location = New Point(153, 42)
        lblTitle.Name = "lblTitle"
        lblTitle.Size = New Size(384, 84)
        lblTitle.TabIndex = 0
        lblTitle.Text = "SCHEDULING SINGLE ROUND ROBIN TOURNAMENT " & vbCrLf & "minimizing simultaneously two objective functions:" & vbCrLf & "(i) total waiting times of teams" & vbCrLf & "(ii) number of long waiting times"
        lblTitle.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' lblNumberOfTeams
        ' 
        lblNumberOfTeams.AutoSize = True
        lblNumberOfTeams.Location = New Point(53, 224)
        lblNumberOfTeams.Name = "lblNumberOfTeams"
        lblNumberOfTeams.Size = New Size(132, 42)
        lblNumberOfTeams.TabIndex = 1
        lblNumberOfTeams.Text = "Number of teams" & vbCrLf & "(must be odd)"
        lblNumberOfTeams.TextAlign = ContentAlignment.MiddleCenter
        ' 
        ' tbxNumberOfTeams
        ' 
        tbxNumberOfTeams.Location = New Point(217, 237)
        tbxNumberOfTeams.Name = "tbxNumberOfTeams"
        tbxNumberOfTeams.Size = New Size(59, 29)
        tbxNumberOfTeams.TabIndex = 2
        ' 
        ' rbtZeroWaitingTimeAllowed
        ' 
        rbtZeroWaitingTimeAllowed.AutoSize = True
        rbtZeroWaitingTimeAllowed.Location = New Point(366, 211)
        rbtZeroWaitingTimeAllowed.Name = "rbtZeroWaitingTimeAllowed"
        rbtZeroWaitingTimeAllowed.Size = New Size(215, 25)
        rbtZeroWaitingTimeAllowed.TabIndex = 3
        rbtZeroWaitingTimeAllowed.TabStop = True
        rbtZeroWaitingTimeAllowed.Text = "Zero waiting times allowed"
        rbtZeroWaitingTimeAllowed.UseVisualStyleBackColor = True
        ' 
        ' rbtZeroWaitingTimeNOTallowed
        ' 
        rbtZeroWaitingTimeNOTallowed.AutoSize = True
        rbtZeroWaitingTimeNOTallowed.Location = New Point(366, 265)
        rbtZeroWaitingTimeNOTallowed.Name = "rbtZeroWaitingTimeNOTallowed"
        rbtZeroWaitingTimeNOTallowed.Size = New Size(250, 25)
        rbtZeroWaitingTimeNOTallowed.TabIndex = 4
        rbtZeroWaitingTimeNOTallowed.TabStop = True
        rbtZeroWaitingTimeNOTallowed.Text = "Zero waiting times NOT allowed"
        rbtZeroWaitingTimeNOTallowed.UseVisualStyleBackColor = True
        ' 
        ' cmdMakeOptimalSchedule
        ' 
        cmdMakeOptimalSchedule.Location = New Point(200, 330)
        cmdMakeOptimalSchedule.Name = "cmdMakeOptimalSchedule"
        cmdMakeOptimalSchedule.Size = New Size(300, 60)
        cmdMakeOptimalSchedule.TabIndex = 5
        cmdMakeOptimalSchedule.Text = "Make Optimal Schedule"
        cmdMakeOptimalSchedule.UseVisualStyleBackColor = True
        ' 
        ' frmMain
        ' 
        AutoScaleMode = AutoScaleMode.None
        ClientSize = New Size(717, 473)
        Controls.Add(cmdMakeOptimalSchedule)
        Controls.Add(rbtZeroWaitingTimeNOTallowed)
        Controls.Add(rbtZeroWaitingTimeAllowed)
        Controls.Add(tbxNumberOfTeams)
        Controls.Add(lblNumberOfTeams)
        Controls.Add(lblTitle)
        Font = New Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point)
        Name = "frmMain"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Scheduling single round robin tournament"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents lblTitle As Label
    Friend WithEvents lblNumberOfTeams As Label
    Friend WithEvents tbxNumberOfTeams As TextBox
    Friend WithEvents rbtZeroWaitingTimeAllowed As RadioButton
    Friend WithEvents rbtZeroWaitingTimeNOTallowed As RadioButton
    Friend WithEvents cmdMakeOptimalSchedule As Button
End Class
